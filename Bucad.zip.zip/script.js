document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("signupForm");
  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();

      // Clear previous error messages
      document.querySelectorAll(".error").forEach(el => el.textContent = "");

      const firstName = document.getElementById("firstName").value.trim();
      const lastName = document.getElementById("lastName").value.trim();
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value.trim();
      const contactNumber = document.getElementById("contactNumber").value.trim();
      const supportReason = document.getElementById("supportReason").value.trim();
      const sexElems = document.getElementsByName("sex");
      let sex = "";
      for (let elem of sexElems) {
        if (elem.checked) sex = elem.value;
      }

      let hasError = false;

      if (!firstName) {
        document.getElementById("errFirstName").textContent = "Required";
        hasError = true;
      }
      if (!lastName) {
        document.getElementById("errLastName").textContent = "Required";
        hasError = true;
      }
      if (!sex) {
        document.getElementById("errSex").textContent = "Required";
        hasError = true;
      }
      if (!email) {
        document.getElementById("errEmail").textContent = "Required";
        hasError = true;
      }
      if (!password) {
        document.getElementById("errPassword").textContent = "Required";
        hasError = true;
      }
      if (!supportReason) {
        document.getElementById("errSupportReason").textContent = "Required";
        hasError = true;
      }

      if (!hasError) {
        // Store in localStorage
        localStorage.setItem("firstName", firstName);
        localStorage.setItem("lastName", lastName);
        localStorage.setItem("email", email);
        localStorage.setItem("sex", sex);
        localStorage.setItem("supportReason", supportReason);

        // Redirect
        window.location.href = "proj_profile_lastname.html";
      }
    });
  }

  // Profile Page Data Population
  if (document.getElementById("profileFirstName")) {
    document.getElementById("profileFirstName").textContent = localStorage.getItem("firstName") || "";
    document.getElementById("profileLastName").textContent = localStorage.getItem("lastName") || "";
    document.getElementById("profileEmail").textContent = localStorage.getItem("email") || "";
    document.getElementById("profileSex").textContent = localStorage.getItem("sex") || "";
    document.getElementById("profileReason").textContent = localStorage.getItem("supportReason") || "";
  }
});
